# dynamodbDemo
