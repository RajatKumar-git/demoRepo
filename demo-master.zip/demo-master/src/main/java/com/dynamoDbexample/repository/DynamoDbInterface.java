package com.dynamoDbexample.repository;

import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.PrimaryKey;
import com.amazonaws.services.dynamodbv2.document.UpdateItemOutcome;
import com.amazonaws.services.dynamodbv2.document.spec.*;

public interface DynamoDbInterface {
    Item getItemByItemSpec(String var1, GetItemSpec var2);

    Item getItemBYPK(String var1, PrimaryKey var2);

    ItemCollection getItemByQuerySpec(String var1, String var2, QuerySpec var3);

    void saveItem(String var1,Item var2);

    void saveItem(String var1, PutItemSpec var2);

    UpdateItemOutcome updateItem(String var1, UpdateItemSpec var2);

    void deleteItemBYSpec(String var1, DeleteItemSpec var2);

    Boolean exists(String var1, PrimaryKey var2);

    ItemCollection getItemBySpec(String var1, ScanSpec var2);
}
