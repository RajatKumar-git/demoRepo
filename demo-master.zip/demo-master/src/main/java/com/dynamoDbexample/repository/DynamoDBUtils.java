package com.dynamoDbexample.repository;

import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@Component("dynamoDBUtils")
public class DynamoDBUtils {

    @Autowired
    private GenericDynamoDbDao genericDynamoDbDao;

    public DynamoDBUtils(){
    }

    public List<String> getNameValueMapAndEqualsConditionsInList(Map<String,Object> condition, NameMap nameMap, ValueMap valueMap){
        List<String> filterConditionInList = new ArrayList();
        Iterator var5 = condition.entrySet().iterator();

        while(var5.hasNext()){
            Entry<String,Object> entry = (Entry)var5.next();
            filterConditionInList.add("#"+(String)entry.getKey() +"= : "+(String)entry.getKey());
            nameMap.put("#"+(String)entry.getKey(),entry.getKey());
            valueMap.put(":"+(String)entry.getKey(),entry.getValue());
        }
        return filterConditionInList;
    }

    public ItemCollection fetchDataForEqualsConditions(Map<String,Object> keyCondition, Map<String,Object> filterCondition,String indexName, String tableName) throws Exception{
        NameMap nameMap = new NameMap();
        ValueMap valueMap = new ValueMap();
        QuerySpec querySpec = new QuerySpec();
        String keyConditionExpression;
        if(MapUtils.isNotEmpty(filterCondition)){
            keyConditionExpression = String.join(" and ",this.getNameValueMapAndEqualsConditionsInList(filterCondition,nameMap,valueMap));
            querySpec.withFilterExpression(keyConditionExpression);
        }

        if(MapUtils.isNotEmpty(keyCondition)){
            keyConditionExpression = String.join(" and ",this.getNameValueMapAndEqualsConditionsInList(filterCondition,nameMap,valueMap));
            querySpec.withFilterExpression(keyConditionExpression);
        }

        querySpec.withNameMap(nameMap);
        querySpec.withValueMap(valueMap);
        return this.genericDynamoDbDao.getItemByQuerySpec(tableName,indexName,querySpec);
    }

    public List<String> getNameValueMapAndConditionInList(Map<String,Map<Object,String>> condition,NameMap nameMap,ValueMap valueMap) throws Exception{
        List<String> filterConditionInList = new ArrayList();
        Iterator var5 = condition.entrySet().iterator();

        while(var5.hasNext()){
            Entry<String,Map<Object,String>> entry = (Entry)var5.next();
            Entry<Object,String> entryMap = (Entry)((Map)entry.getValue()).entrySet().iterator().next();
            filterConditionInList.add("#"+(String)entry.getKey()+(String)entryMap.getValue()+" :"+(String)entry.getKey());
            nameMap.put("#"+(String)entry.getKey(), entry.getKey());
            valueMap.put(":"+(String)entry.getKey(), entryMap.getKey());
        }
        return filterConditionInList;
    }

    public ItemCollection fetchData(Map<String,Map<Object,String>> keyCondition,Map<String,Map<Object,String>> filterCondition,String indexName,String tableName,Integer maxLimit) throws Exception{
        NameMap nameMap = new NameMap();
        ValueMap valueMap = new ValueMap();
        QuerySpec querySpec = new QuerySpec();
        String keyConditionExpression;
        if(MapUtils.isNotEmpty(filterCondition)){
            keyConditionExpression = String.join(" and ",this.getNameValueMapAndConditionInList(filterCondition,nameMap,valueMap));
            querySpec.withFilterExpression(keyConditionExpression);
        }

        if(MapUtils.isNotEmpty(keyCondition)){
            keyConditionExpression = String.join(" and ",this.getNameValueMapAndConditionInList(keyCondition,nameMap,valueMap));
            querySpec.withFilterExpression(keyConditionExpression);
        }

        querySpec.withNameMap(nameMap);
        querySpec.withValueMap(valueMap);
        if(null!=maxLimit) {
            querySpec.withMaxResultSize(maxLimit);
        }

        return this.genericDynamoDbDao.getItemByQuerySpec(tableName,indexName,querySpec);
    }
}
