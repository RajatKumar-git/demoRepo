package com.dynamoDbexample.repository;

import com.amazonaws.services.dynamodbv2.document.*;
import com.amazonaws.services.dynamodbv2.document.spec.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class GenericDynamoDbDao implements DynamoDbInterface{
    @Autowired
    public DynamoDB dynamoDB;

    public GenericDynamoDbDao(){
    }


    public Item getItemByItemSpec(String tableName, GetItemSpec getItemSpec) {
       Table table = this.dynamoDB.getTable(tableName);
       return table.getItem(getItemSpec);
    }


    public Item getItemBYPK(String tableName, PrimaryKey primaryKey) {
        Table table = this.dynamoDB.getTable(tableName);
        return table.getItem(primaryKey);
    }

    public ItemCollection getItemByQuerySpec(String tableName, String indexName, QuerySpec spec) {
        Table table = this.dynamoDB.getTable(tableName);
        ItemCollection<QueryOutcome> items = null;
        if(StringUtils.isNotBlank(indexName)){
            Index index = table.getIndex(indexName);
            items = index.query(spec);
        }else{
            items = table.query(spec);
        }
        return items;
    }

    public void saveItem(String tableName, Item recordItem) {
        Table table = this.dynamoDB.getTable(tableName);
        table.putItem(recordItem);
    }

    public void saveItem(String tableName, PutItemSpec putItemSpec) {
        Table table = this.dynamoDB.getTable(tableName);
        table.putItem(putItemSpec);
    }

    public UpdateItemOutcome updateItem(String tableName, UpdateItemSpec updateItemSpec) {
        Table table = this.dynamoDB.getTable(tableName);
        return table.updateItem(updateItemSpec);
    }

    public void deleteItemBYSpec(String tableName, DeleteItemSpec deleteItemSpec) {
        Table table = this.dynamoDB.getTable(tableName);
        table.deleteItem(deleteItemSpec);
    }

    public Boolean exists(String tableName, PrimaryKey primaryKey) {
        Table table = this.dynamoDB.getTable(tableName);
        Item item = table.getItem(primaryKey);
        return item!=null ? true : false;
    }

    public ItemCollection getItemBySpec(String tableName, ScanSpec spec) {
        Table table = this.dynamoDB.getTable(tableName);
        ItemCollection<ScanOutcome> items = table.scan(spec);
        return items;
    }
}
